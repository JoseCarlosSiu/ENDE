package pruebas;

public class HolaMundo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Nos dice en consola Hola Git
		System.out.println("Hola GiT!!");
	}

}
